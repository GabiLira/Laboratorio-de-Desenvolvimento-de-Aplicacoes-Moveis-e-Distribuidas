package com.example.continuous_entregation

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
