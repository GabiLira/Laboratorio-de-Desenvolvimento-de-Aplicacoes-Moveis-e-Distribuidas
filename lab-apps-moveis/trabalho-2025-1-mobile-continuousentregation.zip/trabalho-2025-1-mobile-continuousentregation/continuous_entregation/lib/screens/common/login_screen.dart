import 'package:continuous_entregation/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../helpers/database_helper.dart';

class LoginClientScreen extends StatefulWidget {
  const LoginClientScreen({super.key});

  @override
  State<LoginClientScreen> createState() => _LoginClientScreenState();
}

class _LoginClientScreenState extends State<LoginClientScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  String? _tipoSelecionado;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _error = '';

  void _login() async {
  final email = _emailController.text.trim();
  final password = _passwordController.text.trim();
  final tipo = _tipoSelecionado == 'Cliente' ? 0 : 1;

  //final client = await DatabaseHelper().getClientByLogin(email, password, tipo);
  final client = await DatabaseHelper().getClientByLoginFirebase(email, password, tipo);

  if (client != null) {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('userId', client['id']);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Login realizado com sucesso!')),
    );

    if (tipo == 0) {
      Navigator.pushReplacementNamed(context, AppRoutes.homeClient);
    } else {
      Navigator.pushReplacementNamed(context, AppRoutes.homeDriver);
    }
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Credenciais inválidas!')),
    );
  }
}

  Future<void> _cadastrar() async {
    Navigator.pushReplacementNamed(context, AppRoutes.register);
  }

  Widget _buildSelectionField(List<String> items) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: DropdownButtonFormField<String>(
        value: _tipoSelecionado,
        items: items.map((String tipo) {
          return DropdownMenuItem<String>(
            value: tipo,
            child: Text(tipo),
          );
        }).toList(),
        decoration: InputDecoration(
          labelText: "Tipo de Usuário",
          labelStyle: TextStyle(color: Color.fromARGB(255, 92, 92, 92)),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.black, width: 2.0),
            borderRadius: BorderRadius.circular(10),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: Color.fromARGB(255, 92, 92, 92),
              width: 1.5,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
        onChanged: (String? newValue) {
          setState(() {
            _tipoSelecionado = newValue;
          });
        },
        validator:
            (value) => value == null ? "Selecione o tipo de usuário" : null,
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login do Cliente')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              if (_error.isNotEmpty)
                Text(_error, style: const TextStyle(color: Colors.red)),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(labelText: 'E-mail'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Senha'),
              ),
               const SizedBox(height: 16),
               _buildSelectionField([
                              "Cliente",
                              "Motorista",
                            ]),
              const SizedBox(height: 32),
              ElevatedButton(onPressed: _login, child: const Text('Entrar')),
              const SizedBox(height: 32),
              ElevatedButton(onPressed: _cadastrar, child: const Text('Cadastrar')),
            ],
          ),
        ),
      ),
    );
  }
}
