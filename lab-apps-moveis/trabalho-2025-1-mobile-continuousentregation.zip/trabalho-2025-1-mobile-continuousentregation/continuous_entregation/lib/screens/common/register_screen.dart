import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:continuous_entregation/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../../helpers/database_helper.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();
  final _confirmarSenhaController = TextEditingController();

  String _tipoUsuario = 'Cliente';
  final List<String> _tipos = ['Cliente', 'Motorista'];

  Future<void> sendToFirebase() async {

    final email = _emailController.text.trim();
    final senha = _senhaController.text;
    final tipo = _tipoUsuario == 'Cliente' ? 0 : 1;

    try{
      if (_formKey.currentState!.validate()) {
        final deliveryData = {
          'email': email, // ID do cliente (pode ser obtido do SharedPreferences)
          'senha': senha,
          'tipo': tipo
        };

      await FirebaseFirestore.instance
        .collection('entregas')
        .doc("clients")
        .collection('client')
        .add(deliveryData);
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastro realizado com sucesso!')),
      );

      // Redirecionamento
      Navigator.pushReplacementNamed(context, AppRoutes.login);

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erro: email já cadastrado')),
      );
    }
  }

  Future<void> _cadastrar() async {
    if (_formKey.currentState!.validate()) {
      final email = _emailController.text.trim();
      final senha = _senhaController.text;
      final tipo = _tipoUsuario == 'Cliente' ? 0 : 1;

      try {
        final db = await DatabaseHelper().database;

        await db.insert(
          'clients',
          {'email': email, 'password': senha, 'tipo': tipo},
          conflictAlgorithm: ConflictAlgorithm.fail,
        );

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cadastro realizado com sucesso!')),
        );

        // Redirecionamento
        Navigator.pushReplacementNamed(context, AppRoutes.login);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Erro: email já cadastrado')),
        );
      }
    }
  }

  Future<bool> isConnected() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    return connectivityResult == ConnectivityResult.mobile ||
    connectivityResult == ConnectivityResult.wifi;
  }

  @override
  void dispose() {
    _emailController.dispose();
    _senhaController.dispose();
    _confirmarSenhaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(labelText: 'Email'),
                keyboardType: TextInputType.emailAddress,
                validator: (value) =>
                    value == null || !value.contains('@') ? 'Email inválido' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _senhaController,
                decoration: const InputDecoration(labelText: 'Senha'),
                obscureText: true,
                validator: (value) =>
                    value != null && value.length >= 6 ? null : 'Mínimo 6 caracteres',
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _confirmarSenhaController,
                decoration: const InputDecoration(labelText: 'Confirmar Senha'),
                obscureText: true,
                validator: (value) =>
                    value == _senhaController.text ? null : 'Senhas não coincidem',
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _tipoUsuario,
                items: _tipos
                    .map((tipo) => DropdownMenuItem(value: tipo, child: Text(tipo)))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _tipoUsuario = value!;
                  });
                },
                decoration: const InputDecoration(labelText: 'Tipo de Usuário'),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: sendToFirebase,
                child: const Text('Cadastrar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
