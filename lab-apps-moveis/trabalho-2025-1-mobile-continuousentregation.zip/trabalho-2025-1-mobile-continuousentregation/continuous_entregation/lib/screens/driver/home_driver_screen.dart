import 'package:continuous_entregation/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeDriverScreen extends StatelessWidget {
  const HomeDriverScreen({super.key});
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Área do Motorista'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/');
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Olá, motorista!',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),

            ElevatedButton.icon(
              icon: const Icon(Icons.list),
              label: const Text('Ver Entregas Disponíveis'),
              onPressed: () async {
                //verifica se existe alguma entrega ativa
                final prefs = await SharedPreferences.getInstance();
                final entrega = prefs.getString('entregaAceita');
                if (entrega != null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Você já tem uma entrega ativa!')),
                  );
                } else {
                  Navigator.pushNamed(context, AppRoutes.acceptDelivery);
                }
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
            ),
            const SizedBox(height: 16),

            ElevatedButton.icon(
              icon: const Icon(Icons.camera_alt),
              label: const Text('Atualizar Entrega com Foto'),
              onPressed: () {
                // Navegar para tela de tirar foto e capturar localização
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                minimumSize: const Size.fromHeight(50),
              ),
            ),
            const SizedBox(height: 16),

            ElevatedButton.icon(
              icon: const Icon(Icons.map),
              label: const Text('Rota da Entrega'),
              onPressed: () {
                Navigator.pushReplacementNamed(context, AppRoutes.deliveryRoute);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: const Size.fromHeight(50),
              ),
            ),
            const SizedBox(height: 16),

            ElevatedButton.icon(
              icon: const Icon(Icons.check_circle),
              label: const Text('Entregas Concluídas'),
              onPressed: () {
                Navigator.pushNamed(context, AppRoutes.historyCompleted);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                minimumSize: const Size.fromHeight(50),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
