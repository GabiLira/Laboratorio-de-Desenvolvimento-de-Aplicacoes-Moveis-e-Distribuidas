import 'dart:convert';

import 'package:continuous_entregation/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../helpers/database_helper.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AvailableDeliveriesScreen extends StatefulWidget {
  const AvailableDeliveriesScreen({super.key});

  @override
  State<AvailableDeliveriesScreen> createState() => _AvailableDeliveriesScreenState();
}

class _AvailableDeliveriesScreenState extends State<AvailableDeliveriesScreen> {
  List<Map<String, dynamic>> _entregasPendentes = [];
  final firestore = FirebaseFirestore.instance;
  String entregaAceita = '';

  @override
  void initState() {
    super.initState();
    _carregarEntregas();
  }

  Future<void> _carregarEntregas() async {
    //final db = await DatabaseHelper().database;
     final List<Map<String, dynamic>> packages = [];

    final results = await firestore
        .collection('entregas')
        .doc("packages")
        .collection('package')
        .get();

    for (var doc in results.docs) {
      final data = doc.data();
      data['id'] = doc.id; // Adiciona o ID do documento ao mapa
      packages.add(data);
    }

    setState(() {
      _entregasPendentes = packages;
    });
  }

  // Future<void> _aceitarEntrega(int id) async {
    
  //   final db = await DatabaseHelper().database;

  //   await db.update(
  //     'package',
  //     {'situacao': 1}, // Atualiza a situação para "em andamento"
  //     where: 'id = ?',
  //     whereArgs: [id],
  //   );

  //   final prefs = await SharedPreferences.getInstance();
  //   final int? idDriver = prefs.getInt('userId');

  //   if (idDriver != null) {
  //     // 3. Insere o vínculo entre motorista e entrega
  //     await db.insert('driver_package', {
  //       'id_driver': idDriver,
  //       'id_package': id,
  //     });
  //   }

  //   ScaffoldMessenger.of(context).showSnackBar(
  //     const SnackBar(content: Text('Entrega aceita com sucesso')),
  //   );

  //   _carregarEntregas(); // Recarrega a lista após aceitar
  // }


Future<void> _aceitarEntrega(String packageId) async {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  

  final prefs = await SharedPreferences.getInstance();
  final String? idDriver = prefs.getString('userId'); // ou getInt se for número

  Position position = await _getCurrentLocation();

  if (idDriver != null) {

    try{
      // Atualiza o status do pacote
      await firestore.collection('entregas').doc("packages").collection("package").doc(packageId).update({
        'situacao': 1,
      });

      // Cria vínculo entre motorista e entrega
      await firestore.collection("entregas").doc("driver_packages").collection('driver_package').add({
        'id_driver': idDriver,
        'id_package': packageId,
        'latitude': position.latitude,
        'longitude': position.longitude
      });
    }catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erro ao aceitar entrega')),
      );
      return;
    }
  }

  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text('Entrega aceita com sucesso')),
  );
  prefs.setString('entregaAceita', packageId); // Salva o ID da entrega aceita
  _carregarEntregas(); // Atualiza a tela
}

Future<Position> _getCurrentLocation() async {
  bool serviceEnabled;
  LocationPermission permission;

  // Verifica se os serviços de localização estão habilitados
  serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    throw Exception('Serviços de localização estão desabilitados.');
  }

  permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      throw Exception('Permissão de localização negada.');
    }
  }

  if (permission == LocationPermission.deniedForever) {
    throw Exception('Permissão de localização negada permanentemente.');
  }

  // Permissão concedida, retorna posição atual
  return await Geolocator.getCurrentPosition();
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Entregas Disponíveis'),
        actions: [
          IconButton(
            icon: const Icon(Icons.home),
            tooltip: 'Voltar ao Início',
            onPressed: () {
              Navigator.pushReplacementNamed(context, AppRoutes.homeDriver);
            },
          ),
        ],
      ),
      body: _entregasPendentes.isEmpty
          ? const Center(child: Text('Nenhuma entrega pendente encontrada.'))
          : ListView.builder(
              itemCount: _entregasPendentes.length,
              itemBuilder: (context, index) {
                final entrega = _entregasPendentes[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    title: Text('De: ${entrega['origem']} → Para: ${entrega['destino']}'),
                    subtitle: Text('Situação: ${entrega['situacao']}'),
                    trailing: ElevatedButton(
                      onPressed: () => _aceitarEntrega(entrega['id']),
                      child: const Text('Aceitar'),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
