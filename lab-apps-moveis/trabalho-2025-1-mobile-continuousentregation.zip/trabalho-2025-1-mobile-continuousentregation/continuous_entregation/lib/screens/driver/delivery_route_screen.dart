import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class RotaEntregaScreen extends StatefulWidget {

  const RotaEntregaScreen({
    super.key,
  });

  @override
  State<RotaEntregaScreen> createState() => _RotaEntregaScreenState();
}

class _RotaEntregaScreenState extends State<RotaEntregaScreen> {
  GoogleMapController? _mapController;
  Set<Polyline> _polylines = {};
  Set<Marker> _markers = {};

  static const String _apiKey = 'ChaveAPI'; // Substitua pela sua chave da API do Google Maps

  Position? localizacao;
  

  Future<LatLng?> getCoordinatesFromAddress(String address, String apiKey) async {
  final url = Uri.parse(
    'https://maps.googleapis.com/maps/api/geocode/json?address=${Uri.encodeComponent(address)}&key=$apiKey',
  );

  final response = await http.get(url);

  if (response.statusCode == 200) {
    final data = jsonDecode(response.body);
    if (data['status'] == 'OK') {
      final location = data['results'][0]['geometry']['location'];
      return LatLng(location['lat'], location['lng']);
    } else {
      print('Geocode API error: ${data['status']}');
    }
  } else {
    print('HTTP error: ${response.statusCode}');
  }

  return null;
}

Future<void> gerarRotaComEnderecos({
  required String enderecoColeta,
  required String enderecoEntrega,
  required LatLng localAtualMotorista,
  required String googleApiKey,
}) async {
  final LatLng? origem = localAtualMotorista;
  final LatLng? coleta = await getCoordinatesFromAddress(enderecoColeta, googleApiKey);
  final LatLng? destino = await getCoordinatesFromAddress(enderecoEntrega, googleApiKey);

  if (coleta == null || destino == null) {
    print("Erro ao geocodificar um dos endereços.");
    return;
  }

  final url = Uri.parse(
    'https://maps.googleapis.com/maps/api/directions/json'
    '?origin=${origem?.latitude},${origem?.longitude}'
    '&waypoints=${coleta.latitude},${coleta.longitude}'
    '&destination=${destino.latitude},${destino.longitude}'
    '&key=$googleApiKey',
  );

  final response = await http.get(url);
  final data = jsonDecode(response.body);

  if (data['status'] == 'OK') {
    final polyline = data['routes'][0]['overview_polyline']['points'];
    print('Polyline da rota: $polyline');
    // Você pode decodificar e desenhar a rota no mapa aqui
  } else {
    print('Erro ao gerar rota: ${data['status']}');
  }
}

Future<Position> _getCurrentLocation() async {
  bool serviceEnabled;
  LocationPermission permission;

  // Verifica se os serviços de localização estão habilitados
  serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    throw Exception('Serviços de localização estão desabilitados.');
  }

  permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      throw Exception('Permissão de localização negada.');
    }
  }

  if (permission == LocationPermission.deniedForever) {
    throw Exception('Permissão de localização negada permanentemente.');
  }

  // Permissão concedida, retorna posição atual
  return await Geolocator.getCurrentPosition();
} 

  @override
  void initState() {
    super.initState();
    _gerarRota();
  }

  Future<void> _gerarRota() async {
    final FirebaseFirestore firestore = FirebaseFirestore.instance;
    final prefs = await SharedPreferences.getInstance();

    String entregaAceita = prefs.getString('entregaAceita') ?? '';

    final result = await firestore
        .collection('entregas')
        .doc("packages")
        .collection('package')
        .doc(entregaAceita)
        .get();
    final data = result.data();

    localizacao = await _getCurrentLocation();


    final origem = LatLng(localizacao!.latitude, localizacao!.longitude); // Exemplo de coordenadas
    final LatLng? coleta = await getCoordinatesFromAddress(data?['origem'], _apiKey); // Coordenadas do ponto de coleta
    final LatLng? destino = await getCoordinatesFromAddress(data?['destino'], _apiKey); // Coordenadas do destino

    final url = Uri.parse(
      'https://maps.googleapis.com/maps/api/directions/json'
      '?origin=${origem.latitude},${origem.longitude}'
      '&destination=${destino!.latitude},${destino!.longitude}'
      '&waypoints=${coleta!.latitude},${coleta!.longitude}'
      '&key=$_apiKey',
    );

    final response = await http.get(url);
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final points = _decodePolyline(
          data['routes'][0]['overview_polyline']['points']);

      setState(() {
        _polylines.add(Polyline(
          polylineId: const PolylineId('rota_entrega'),
          points: points,
          width: 5,
          color: Colors.blue,
        ));

        _markers.add(Marker(
            markerId: const MarkerId('origem'),
            position: origem,
            infoWindow: const InfoWindow(title: 'Motorista')));
        _markers.add(Marker(
            markerId: const MarkerId('coleta'),
            position: coleta,
            infoWindow: const InfoWindow(title: 'Ponto de Coleta')));
        _markers.add(Marker(
            markerId: const MarkerId('destino'),
            position: destino,
            infoWindow: const InfoWindow(title: 'Destino Final')));
      });
    } else {
      print('Erro na rota: ${response.body}');
    }
  }

  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }

    return points;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rota da Entrega')),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: LatLng(localizacao!.latitude, localizacao!.longitude),
          zoom: 14,
        ),
        onMapCreated: (controller) => _mapController = controller,
        markers: _markers,
        polylines: _polylines,
      ),
    );
  }
}
