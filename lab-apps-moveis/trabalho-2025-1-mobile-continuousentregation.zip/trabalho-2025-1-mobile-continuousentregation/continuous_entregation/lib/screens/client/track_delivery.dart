import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:continuous_entregation/helpers/database_helper.dart';
import 'package:continuous_entregation/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../helpers/database_helper.dart';

class RastrearPedidoScreen extends StatefulWidget {
  const RastrearPedidoScreen({super.key});

  @override
  State<RastrearPedidoScreen> createState() => _RastrearPedidoScreenState();
}

class _RastrearPedidoScreenState extends State<RastrearPedidoScreen> {
  List<Map<String, dynamic>> _packages = [];

  @override
  void initState() {
    super.initState();
    _loadPackages();
  }

  // Future<void> _loadPackages() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   final userId = prefs.getInt('userId');

  //   if (userId != null) {
  //     final packages = await DatabaseHelper().getPackagesInProgressForClient(userId);
  //     setState(() {
  //       _packages = packages;
  //     });
  //   }
    
  // }

  Future<void> _loadPackages() async {
  final prefs = await SharedPreferences.getInstance();
  final userId = prefs.getString('userId'); 

  if (userId != null) {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('entregas')
        .doc("packages")
        .collection('package')
        .where('id_driver', isEqualTo: userId) // Filtra pacotes do motorista
        .where('situacao', isEqualTo: 1) // 1 = em andamento
        .get();

    List<Map<String, dynamic>> packages = [];
    for (var doc in querySnapshot.docs) {
      final data = doc.data();
      data['id'] = doc.id; // Adiciona o ID do documento ao mapa
      packages.add(data);
    }

    setState(() {
      _packages = packages; // Atualiza o estado com os pacotes carregados
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rastrear Pedido'),
         actions: [
          IconButton(
            icon: const Icon(Icons.home),
            tooltip: 'Voltar ao Início',
            onPressed: () {
              Navigator.pushReplacementNamed(context, AppRoutes.homeClient);
            },
          ),
        ],
      ),
      body: _packages.isEmpty
          ? const Center(child: Text('Nenhum pedido em andamento.'))
          : ListView.builder(
              itemCount: _packages.length,
              itemBuilder: (context, index) {
                final pacote = _packages[index];
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    title: Text('Destino: ${pacote['destino']}'),
                    subtitle: Text('Origem: ${pacote['origem']}'),
                    trailing: const Text('🚚 Em andamento'),
                  ),
                );
              },
            ),
    );
  }
}
