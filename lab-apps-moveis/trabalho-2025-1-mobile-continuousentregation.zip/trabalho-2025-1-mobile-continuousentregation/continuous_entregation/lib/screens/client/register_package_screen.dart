import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../helpers/database_helper.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class RegisterPackageScreen extends StatefulWidget {
  const RegisterPackageScreen({super.key});

  @override
  State<RegisterPackageScreen> createState() => _RegisterPackageScreenState();
}

class _RegisterPackageScreenState extends State<RegisterPackageScreen> {
  final _formKey = GlobalKey<FormState>();
  final _origemController = TextEditingController();
  final _destinoController = TextEditingController();
  int _indexSituacaoSelecionada = 0; //pendente




  Future<void> sendToFirebase() async {
    final prefs = await SharedPreferences.getInstance();
    final String? idClient = prefs.getString('userId');

    final deliveryData = {
        'id_client': idClient, // ID do cliente (pode ser obtido do SharedPreferences)
        'origem': _origemController.text.trim(),
        'destino': _destinoController.text.trim(),
        'situacao': _indexSituacaoSelecionada,
      };
    await FirebaseFirestore.instance
    .collection('entregas')
    .doc("packages")
    .collection('package')
    .add(deliveryData);
  }


  Future<void> _salvarEncomenda() async {
    if (_formKey.currentState!.validate()) {
      final db = await DatabaseHelper().database;

      final prefs = await SharedPreferences.getInstance();
      final int? idClient = prefs.getInt('userId');

      await db.insert('package', {
        'id_client': idClient, // ID do cliente (pode ser obtido do SharedPreferences)
        'origem': _origemController.text.trim(),
        'destino': _destinoController.text.trim(),
        'situacao': _indexSituacaoSelecionada,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Encomenda cadastrada com sucesso')),
      );

      _formKey.currentState!.reset();
      setState(() {
        _indexSituacaoSelecionada = 0;
      });
    }
  }

  @override
  void dispose() {
    _origemController.dispose();
    _destinoController.dispose();
    super.dispose();
  }

  Future<bool> isConnected() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    return connectivityResult == ConnectivityResult.mobile ||
    connectivityResult == ConnectivityResult.wifi;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastrar Encomenda')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _origemController,
                decoration: const InputDecoration(labelText: 'Origem'),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Informe a origem' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _destinoController,
                decoration: const InputDecoration(labelText: 'Destino'),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Informe o destino' : null,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: sendToFirebase,
                child: const Text('Salvar Encomenda'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
